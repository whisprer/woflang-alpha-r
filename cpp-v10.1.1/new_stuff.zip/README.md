[README.md]

<p align="center">
  <a href="https://github.com/whispr-dev/woflang-devrepo">
    <img src="https://img.shields.io/github/stars/whispr-dev/woflang-devrepo?style=for-the-badge" alt="GitHub stars" />
  </a>
  <a href="https://github.com/whispr-dev/woflang-devrepo/issues">
    <img src="https://img.shields.io/github/issues/whispr-dev/woflang-devrepo?style=for-the-badge" alt="GitHub issues" />
  </a>
  <a href="https://github.com/whispr-dev/woflang-devrepo/fork">
    <img src="https://img.shields.io/github/forks/whispr-dev/woflang-devrepo?style=for-the-badge" alt="GitHub forks" />
  </a>
</p>
