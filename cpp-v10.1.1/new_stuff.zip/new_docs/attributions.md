# Attributions  

- Inspired by Forth, J, symbolic math traditions  
- Unicode Consortium for symbol standards  
- C++ open source community  
- SIMD & compiler contributors worldwide  

**Special thanks to**:  
The artistic programmers and dreamers making code beautiful.

and ofc:
- G-Petey & Claude.

written by:
- whisprer