# Licensing  

Hybrid MIT + CC0  
- Code: MIT License  
- Artifacts (logos, ritual glyphs, text art): CC0  

**Free to use, modify, extend—preserve attributions where appropriate.**

**See `/HYBRID_LICENCE.md` for details.**