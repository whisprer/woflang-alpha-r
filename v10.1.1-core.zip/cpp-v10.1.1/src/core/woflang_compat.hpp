#pragma once
#include <cmath>
#include <numbers>
#ifndef M_PI
#define M_PI (std::numbers::pi_v<double>)
#endif
